package com.taallammaana.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF263238)
private val Cream = Color(0xFFFFF8E8)
private val Pink = Color(0xFFFFE1EC)
private val Blue = Color(0xFFDDEEFF)
private val Green = Color(0xFFE0F5E8)
private val Purple = Color(0xFFEDE4FF)
private val Orange = Color(0xFFFFE8CC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TaallamMaanaApp() }
    }
}

data class LearningSection(val title: String, val subtitle: String, val emoji: String, val color: Color)

@Composable
fun TaallamMaanaApp() {
    var selected by remember { mutableStateOf("الرئيسية") }
    var stars by remember { mutableIntStateOf(0) }
    var currentLetter by remember { mutableIntStateOf(0) }
    var quizAnswer by remember { mutableStateOf<String?>(null) }

    val sections = listOf(
        LearningSection("الحروف العربية", "نتعرف على الحروف", "أ ب ت", Pink),
        LearningSection("الأرقام والحساب", "نعدّ ونحسب معاً", "١ ٢ ٣", Blue),
        LearningSection("الألوان", "اكتشف عالم الألوان", "🎨", Green),
        LearningSection("الأشكال", "أشكال من حولنا", "⭐", Purple),
        LearningSection("ألعاب الذكاء", "فكّر وأجب", "🧩", Orange),
        LearningSection("قصص الأطفال", "حكايات جميلة", "📖", Pink)
    )

    CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Surface(modifier = Modifier.fillMaxSize(), color = Cream) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFFFD36E)).padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("تعلّم معنا", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                        Text("نتعلّم ونمرح كل يوم!", fontSize = 13.sp, color = Ink)
                    }
                    Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) {
                        Text("⭐ $stars", modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp), fontWeight = FontWeight.Bold, color = Ink)
                    }
                }

                when (selected) {
                    "الحروف العربية" -> LetterLesson(currentLetter) { currentLetter = (currentLetter + 1) % 6; stars += 1 }
                    "الأرقام والحساب" -> NumberLesson { stars += 1 }
                    "الألوان" -> ColorLesson { stars += 1 }
                    "الأشكال" -> ShapeLesson { stars += 1 }
                    "ألعاب الذكاء" -> QuizLesson(quizAnswer, { quizAnswer = it }, { stars += 1 })
                    "قصص الأطفال" -> StoryLesson()
                    else -> HomeScreen(sections) { selected = it }
                }

                Spacer(Modifier.weight(1f))
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color.White).padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("الرئيسية", "الحروف العربية", "الأرقام والحساب", "ألعاب الذكاء").forEach { item ->
                        Text(
                            text = when (item) { "الرئيسية" -> "🏠\nالرئيسية"; "الحروف العربية" -> "🔤\nالحروف"; "الأرقام والحساب" -> "🔢\nالأرقام"; else -> "🧩\nألعاب" },
                            textAlign = TextAlign.Center, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable { selected = item }.padding(horizontal = 5.dp, vertical = 4.dp),
                            color = if (selected == item) Color(0xFFB36A00) else Ink
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(sections: List<LearningSection>, onOpen: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        Text("مرحباً يا بطل! 🌟", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text("ماذا تريد أن تتعلّم اليوم؟", fontSize = 16.sp, color = Color(0xFF657078), modifier = Modifier.padding(top = 5.dp, bottom = 16.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(sections) { section ->
                Surface(
                    modifier = Modifier.fillMaxWidth().height(142.dp).clickable { onOpen(section.title) },
                    color = section.color, shape = RoundedCornerShape(24.dp), shadowElevation = 2.dp
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Text(section.emoji, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                        Column {
                            Text(section.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text(section.subtitle, fontSize = 11.sp, color = Color(0xFF53616A))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LessonFrame(title: String, description: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text(description, fontSize = 14.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp, bottom = 22.dp))
        content()
    }
}

@Composable
fun LetterLesson(index: Int, onNext: () -> Unit) {
    val letters = listOf("أ", "ب", "ت", "ث", "ج", "ح")
    val words = listOf("أسد 🦁", "بطة 🦆", "تفاحة 🍎", "ثعلب 🦊", "جمل 🐪", "حصان 🐴")
    LessonFrame("الحروف العربية", "شاهد الحرف وردّده بصوت عالٍ") {
        Surface(color = Pink, shape = RoundedCornerShape(30.dp), modifier = Modifier.fillMaxWidth().height(190.dp)) {
            Box(contentAlignment = Alignment.Center) { Text(letters[index], fontSize = 100.sp, fontWeight = FontWeight.Black, color = Color(0xFFB33A69)) }
        }
        Text(words[index], fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(24.dp), color = Ink)
        Button(onClick = onNext, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEC8BAF))) { Text("الحرف التالي ⭐") }
    }
}

@Composable
fun NumberLesson(onCorrect: () -> Unit) {
    var chosen by remember { mutableStateOf<Int?>(null) }
    LessonFrame("الأرقام والحساب", "كم عدد التفاحات؟") {
        Text("🍎  🍎  🍎", fontSize = 42.sp, modifier = Modifier.padding(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            (2..4).forEach { n ->
                Button(onClick = { chosen = n; if (n == 3) onCorrect() }, colors = ButtonDefaults.buttonColors(containerColor = if (n == 3) Color(0xFF65B985) else Color(0xFF6FA9E8))) { Text("$n", fontSize = 24.sp) }
            }
        }
        chosen?.let { Text(if (it == 3) "أحسنت! إجابة صحيحة 🎉" else "حاول مرة أخرى 💪", modifier = Modifier.padding(18.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp) }
    }
}

@Composable
fun ColorLesson(onDone: () -> Unit) {
    var selected by remember { mutableStateOf("") }
    LessonFrame("عالم الألوان", "اضغط على اللون الذي يشبه العشب") {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("أحمر" to Color.Red, "أخضر" to Color(0xFF38A169), "أزرق" to Color.Blue).forEach { (name, color) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { selected = name; if (name == "أخضر") onDone() }) {
                    Surface(color = color, shape = RoundedCornerShape(18.dp), modifier = Modifier.size(76.dp)) {}
                    Text(name, modifier = Modifier.padding(8.dp), fontWeight = FontWeight.Bold)
                }
            }
        }
        if (selected.isNotEmpty()) Text(if (selected == "أخضر") "رائع! 🌟" else "جرّب مرة أخرى", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ShapeLesson(onDone: () -> Unit) {
    var selected by remember { mutableStateOf("") }
    LessonFrame("الأشكال الهندسية", "اختر الشكل الدائري") {
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("دائرة" to "🔵", "مربع" to "🟦", "مثلث" to "🔺").forEach { (name, emoji) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { selected = name; if (name == "دائرة") onDone() }) {
                    Text(emoji, fontSize = 48.sp)
                    Text(name, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (selected.isNotEmpty()) Text(if (selected == "دائرة") "أحسنت! 🎉" else "حاول من جديد", modifier = Modifier.padding(18.dp), fontSize = 20.sp)
    }
}

@Composable
fun QuizLesson(answer: String?, onAnswer: (String) -> Unit, onCorrect: () -> Unit) {
    var rewarded by remember { mutableStateOf(false) }
    LessonFrame("لعبة الذكاء 🧩", "أي حيوان يقول مياو؟") {
        Text("🐶      🐱      🐮", fontSize = 48.sp, modifier = Modifier.padding(24.dp))
        listOf("الكلب", "القطة", "البقرة").forEach { option ->
            Button(onClick = { onAnswer(option); if (option == "القطة" && !rewarded) { rewarded = true; onCorrect() } }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E78C8))) { Text(option, fontSize = 18.sp) }
        }
        answer?.let { Text(if (it == "القطة") "إجابة صحيحة! برافو ⭐" else "حاول مرة أخرى", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp) }
    }
}

@Composable
fun StoryLesson() {
    LessonFrame("قصة الأرنب والسلحفاة 🐢", "قصة قصيرة نتعلم منها") {
        Text("🐰       🐢", fontSize = 56.sp, modifier = Modifier.padding(12.dp))
        Text("كان الأرنب سريعاً وكان يفتخر بسرعته. تحدّته السلحفاة في سباق. بدأ الأرنب يجري ثم نام تحت شجرة، أما السلحفاة فواصلت السير بهدوء حتى وصلت إلى خط النهاية وفازت بالسباق.", fontSize = 19.sp, lineHeight = 30.sp, textAlign = TextAlign.Center, color = Ink)
        Text("العبرة: بالمثابرة والصبر نصل إلى الهدف ❤️", fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 18.dp), color = Color(0xFFB36A00))
    }
}
